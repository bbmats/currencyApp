/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.currency.ejb;

import com.currency.entities.Currency;
import com.currency.interceptor.CurrencyInterceptor;
import java.math.BigDecimal;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Resource;
import javax.annotation.security.RolesAllowed;
import javax.ejb.Stateless;
import javax.ejb.LocalBean;
import javax.ejb.SessionContext;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 *
 * @author bbdnet0954
 */
@Stateless
@LocalBean

@Interceptors({CurrencyInterceptor.class})
@RolesAllowed("admin")
public class CurrencySessionBean {

    // @PersistenceContext(unitName = "com.currency_CurrencyApplication-ejb_ejb_1.0-SNAPSHOTPU")
    @PersistenceContext
    private EntityManager em;
    @Resource
    SessionContext ctx;

    public void persist(Object object) {
        try {
    
            em.persist(object);

        } catch (Exception e) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", e);
            throw new RuntimeException(e);
        }
    }

    public List<Currency> retrieveCurrencies() {
   
        Query query = em.createNamedQuery("Currency.findAll");
        return query.getResultList();
    }

    public Currency retrieveCurrency(String currencyCd) {
        Query query = em.createNamedQuery("Currency.findByCurrencycd");
        query.setParameter("currencycd", currencyCd);
        List<Currency> queryResultList = query.getResultList();
        for (Currency currency : queryResultList) {
            return currency;
        }
        return null;
    }

    public Double retrieveCurrencyRate(long currencyCd) {
        Query query = em.createNamedQuery("Currency.findByCurrencyno");
        query.setParameter("currencyno", currencyCd);
        List<Currency> queryResultList = query.getResultList();
        for (Currency currency : queryResultList) {
            return currency.getCurrencyrate().doubleValue();
        }
        return BigDecimal.ZERO.doubleValue();
    }

    public void createCurrency(String currencyCd, String curencyDescription, double currencyRate) {
        Currency currency = retrieveCurrency(currencyCd);
        Currency newCurrency = new Currency();
        if (currency == null) {
            newCurrency.setCurrencyno(currencyCount() + 1);
            newCurrency.setCurrencycd(currencyCd);
            newCurrency.setCurrencydescription(curencyDescription);
            newCurrency.setCurrencyrate(BigDecimal.valueOf(currencyRate));
            newCurrency.setUsername("temp");
            em.persist(newCurrency);
        }
    }

    public void updateCurrency(String beforeCurrencyCd, String currencyCd, String curencyDescription, double currencyRate) {
        Currency currency = retrieveCurrency(beforeCurrencyCd);
        currency.setCurrencycd(currencyCd);
        currency.setCurrencydescription(curencyDescription);
        currency.setCurrencyrate(BigDecimal.valueOf(currencyRate));
        em.merge(currency);

    }

    public int currencyCount() {
        return retrieveCurrencies().size();
    }

    public void removeCurrencies() {
        Query query = em.createNamedQuery("Currency.deleteAll");
        query.executeUpdate();
    }

}
