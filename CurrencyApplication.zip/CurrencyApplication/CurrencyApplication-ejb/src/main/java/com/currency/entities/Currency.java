/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.currency.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author bbdnet0954
 */
@Entity
@Table(name = "CURRENCY", catalog = "", schema = "CURRENCYADMIN", uniqueConstraints = {
    @UniqueConstraint(columnNames = {"CURRENCYCD"})})
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Currency.findAll", query = "SELECT c FROM Currency c")
    ,   @NamedQuery(name = "Currency.deleteAll", query = "DELETE FROM Currency c")
    , @NamedQuery(name = "Currency.findByCurrencyno", query = "SELECT c FROM Currency c WHERE c.currencyno = :currencyno")
    , @NamedQuery(name = "Currency.findByCurrencycd", query = "SELECT c FROM Currency c WHERE c.currencycd = :currencycd")
    , @NamedQuery(name = "Currency.findByCurrencydescription", query = "SELECT c FROM Currency c WHERE c.currencydescription = :currencydescription")
    , @NamedQuery(name = "Currency.findByCurrencyrate", query = "SELECT c FROM Currency c WHERE c.currencyrate = :currencyrate")
    , @NamedQuery(name = "Currency.findByUsername", query = "SELECT c FROM Currency c WHERE c.username = :username")})
public class Currency implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "CURRENCYNO", nullable = false)
    private Integer currencyno;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 20)
    @Column(name = "CURRENCYCD", nullable = false, length = 20)
    private String currencycd;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 40)
    @Column(name = "CURRENCYDESCRIPTION", nullable = false, length = 40)
    private String currencydescription;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Basic(optional = false)
    @NotNull
    @Column(name = "CURRENCYRATE", nullable = false, precision = 8, scale = 8)
    private BigDecimal currencyrate;
    @Size(max = 50)
    @Column(name = "USERNAME", length = 50)
    private String username;

    public Currency() {
    }

    public Currency(Integer currencyno) {
        this.currencyno = currencyno;
    }

    public Currency(Integer currencyno, String currencycd, String currencydescription, BigDecimal currencyrate) {
        this.currencyno = currencyno;
        this.currencycd = currencycd;
        this.currencydescription = currencydescription;
        this.currencyrate = currencyrate;
    }

    public Integer getCurrencyno() {
        return currencyno;
    }

    public void setCurrencyno(Integer currencyno) {
        this.currencyno = currencyno;
    }

    public String getCurrencycd() {
        return currencycd;
    }

    public void setCurrencycd(String currencycd) {
        this.currencycd = currencycd;
    }

    public String getCurrencydescription() {
        return currencydescription;
    }

    public void setCurrencydescription(String currencydescription) {
        this.currencydescription = currencydescription;
    }

    public BigDecimal getCurrencyrate() {
        return currencyrate;
    }

    public void setCurrencyrate(BigDecimal currencyrate) {
        this.currencyrate = currencyrate;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (currencyno != null ? currencyno.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Currency)) {
            return false;
        }
        Currency other = (Currency) object;
        if ((this.currencyno == null && other.currencyno != null) || (this.currencyno != null && !this.currencyno.equals(other.currencyno))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.currency.entities.Currency[ currencyno=" + currencyno + " ]";
    }

}
