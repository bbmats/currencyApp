/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.currency.ejb;

import com.currency.entities.Audit;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Resource;
import javax.annotation.security.RolesAllowed;
import javax.ejb.Stateless;
import javax.ejb.LocalBean;
import javax.ejb.SessionContext;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 *
 * @author bbdnet0954
 */
@Stateless
@LocalBean
@RolesAllowed("admin")
public class AuditSessionBean {

    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")
    @PersistenceContext
    private EntityManager em;
    @Resource
    SessionContext ctx;

    public void persist(Object object) {
        try {
           
                em.persist(object);


        } catch (Exception e) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", e);
            throw new RuntimeException(e);
        }
    }

    public void createAudit(String userName, String methodName) {
       
        Audit audit = new Audit();
        audit.setAuditmethod(methodName);
        audit.setAudituser(userName);
        audit.setAudittime(new Date());
        audit.setAuditno((int) (retrieveAuditCount() + 1));
        em.persist(audit);
    }

    public long retrieveAuditCount() {
        Query query = em.createNamedQuery("Audit.count");
        return (long) query.getSingleResult();
    }
}
