/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.currency.interceptor;

/**
 *
 * @author bbdnet0954
 */
import com.currency.ejb.AuditSessionBean;
import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.ejb.SessionContext;
import javax.interceptor.AroundInvoke;
import javax.interceptor.InvocationContext;

public class CurrencyInterceptor {

        @Resource  
        SessionContext ejbContext;
        
        @EJB
        AuditSessionBean auditBean;

     @AroundInvoke
    public Object intercept(InvocationContext context) throws Exception {
        auditBean.createAudit(ejbContext.getCallerPrincipal().getName(), context.getMethod().getName());
        Object result = context.proceed();
        return result;
    }

}
