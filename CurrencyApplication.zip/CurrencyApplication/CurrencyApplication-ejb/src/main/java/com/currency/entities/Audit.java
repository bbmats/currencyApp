/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.currency.entities;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author bbdnet0954
 */
@Entity
@Table(name = "AUDIT", catalog = "", schema = "CURRENCYADMIN")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Audit.findAll", query = "SELECT a FROM Audit a")
    , @NamedQuery(name = "Audit.findByAuditno", query = "SELECT a FROM Audit a WHERE a.auditno = :auditno")
    , @NamedQuery(name = "Audit.findByAudituser", query = "SELECT a FROM Audit a WHERE a.audituser = :audituser")
    , @NamedQuery(name = "Audit.findByAuditmethod", query = "SELECT a FROM Audit a WHERE a.auditmethod = :auditmethod")
    , @NamedQuery(name = "Audit.findByAudittime", query = "SELECT a FROM Audit a WHERE a.audittime = :audittime")
    , @NamedQuery(name = "Audit.count", query = "SELECT count(a.auditno) FROM Audit a")})  
public class Audit implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "AUDITNO", nullable = false)
    private Integer auditno;
    @Size(max = 40)
    @Column(name = "AUDITUSER", length = 40)
    private String audituser;
    @Size(max = 30)
    @Column(name = "AUDITMETHOD", length = 30)
    private String auditmethod;
    @Column(name = "AUDITTIME")
    @Temporal(TemporalType.TIMESTAMP)
    private Date audittime;

    public Audit() {
    }

    public Audit(Integer auditno) {
        this.auditno = auditno;
    }

    public Integer getAuditno() {
        return auditno;
    }

    public void setAuditno(Integer auditno) {
        this.auditno = auditno;
    }

    public String getAudituser() {
        return audituser;
    }

    public void setAudituser(String audituser) {
        this.audituser = audituser;
    }

    public String getAuditmethod() {
        return auditmethod;
    }

    public void setAuditmethod(String auditmethod) {
        this.auditmethod = auditmethod;
    }

    public Date getAudittime() {
        return audittime;
    }

    public void setAudittime(Date audittime) {
        this.audittime = audittime;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (auditno != null ? auditno.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Audit)) {
            return false;
        }
        Audit other = (Audit) object;
        if ((this.auditno == null && other.auditno != null) || (this.auditno != null && !this.auditno.equals(other.auditno))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.currency.entities.Audit[ auditno=" + auditno + " ]";
    }
    
}
