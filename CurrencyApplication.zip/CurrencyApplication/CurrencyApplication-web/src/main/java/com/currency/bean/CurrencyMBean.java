/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.currency.bean;

import com.currency.ejb.CurrencySessionBean;
import com.currency.entities.Currency;
import java.io.IOException;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.EJB;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;
import javax.ws.rs.ClientErrorException;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.WebTarget;
import service.CurrencyFacadeREST;

/**
 *
 * @author bbdnet0954
 */
@Named(value = "currencyMBean")
@SessionScoped
public class CurrencyMBean implements Serializable {

    @EJB
    private CurrencySessionBean currencySessionBean;
    @EJB
    private CurrencyFacadeREST currencyFacade;

    long fromCurrency;
    long toCurrency;
    double fromCurrencyValue;
    double conversionValue;
    double effectiveRate;

    /**
     * Creates a new instance of CurrencyMBean
     */
    public CurrencyMBean() {
    }

    public List<Currency> getCurrencies() {
        System.out.println("Calculation from ");
        return currencySessionBean.retrieveCurrencies();
    }

    public CurrencySessionBean getCurrencySessionBean() {
        return currencySessionBean;
    }

    public void setCurrencySessionBean(CurrencySessionBean currencySessionBean) {
        this.currencySessionBean = currencySessionBean;
    }

    public long getToCurrency() {
        return toCurrency;
    }

    public void setToCurrency(long toCurrency) {
        this.toCurrency = toCurrency;
    }

    public double getFromCurrencyValue() {
        return fromCurrencyValue;
    }

    public void setFromCurrencyValue(double fromCurrencyValue) {
        this.fromCurrencyValue = fromCurrencyValue;
    }

    public double getConversionValue() {
        return conversionValue;
    }

    public void setConversionValue(double conversionValue) {
        this.conversionValue = conversionValue;
    }

    public double getEffectiveRate() {
        return effectiveRate;
    }

    public void setEffectiveRate(double effectiveRate) {
        this.effectiveRate = effectiveRate;
    }

    public long getFromCurrency() {
        return fromCurrency;
    }

    public void setFromCurrency(long fromCurrency) {
        this.fromCurrency = fromCurrency;
    }

    public void calculateRate() {

        if (fromCurrency != 0 && toCurrency != 0) {

            //System.out.println("Calculation2");
            double fromCurrencyRate = currencySessionBean.retrieveCurrencyRate(fromCurrency);
            double toCurrencyRate = currencySessionBean.retrieveCurrencyRate(toCurrency);

            conversionValue = (fromCurrencyValue * fromCurrencyRate) / toCurrencyRate;
            effectiveRate = fromCurrencyRate / toCurrencyRate;
            //msg = new FacesMessage("Converted Value = " + Double.toString(conversionValue) + "dfdsf" + toCurrencyRate);
        }
        //FacesContext.getCurrentInstance().addMessage(null, msg); 
    }

    /**
     * * Returns the selected Customer object * @return
     * @return 
     */
    public Currency getDetails() {
        //Can either do this for simplicity or fetch the details again from the        
        //database using the Customer ID        
        return null;
    }

    public void logout() {
        ExternalContext externalContext
                = FacesContext.getCurrentInstance().getExternalContext();
        boolean userAuthenticated = externalContext.getRemoteUser() != null;
        if (userAuthenticated) {
            HttpSession session = (HttpSession) externalContext.getSession(false);
            session.invalidate();
            try {
                externalContext.redirect("login.xhtml");
            } catch (IOException ex) {
                Logger.getLogger(CurrencyMBean.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

}
