package com.currency.bean;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import com.currency.ejb.CurrencySessionBean;
import com.currency.entities.Currency;
import java.io.Serializable;
import java.util.List;
import javax.ejb.EJB;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;

/**
 *
 * @author Libusengr
 */
@Named(value = "newCurrencyMBean")
@SessionScoped
public class NewCurrencyMBean implements Serializable {

    @EJB
    private CurrencySessionBean currencySessionBean1;
    private boolean edit;
    private String currencyCd;
    private String currencyDescr;
    private double currencyRate;
    private Currency beforeCurrency;

    private void resetBean() {
        currencyCd = "";
        currencyDescr = "";
        currencyRate = 0;
    }

    /**
     * Creates a new instance of NewCurrencyMBean
     */
    public NewCurrencyMBean() {
    }

    public String getCurrencyCd() {
        return currencyCd;
    }

    public void setCurrencyCd(String currencyCd) {
        this.currencyCd = currencyCd;
    }

    public String getCurrencyDescr() {
        return currencyDescr;
    }

    public void setCurrencyDescr(String currencyDescr) {
        this.currencyDescr = currencyDescr;
    }

    public double getCurrencyRate() {
        return currencyRate;
    }

    public void setCurrencyRate(double currencyRate) {
        this.currencyRate = currencyRate;
    }

    public void addNewCurrency() {

        if (currencyCd != null && currencyDescr != null && currencyRate != 0) {
            currencySessionBean1.createCurrency(currencyCd, currencyDescr, currencyRate);
            resetBean();
        }
    }

    public void updateCurrency() {

        if (currencyCd != null && currencyDescr != null && currencyRate != 0) {
            currencySessionBean1.updateCurrency(beforeCurrency.getCurrencycd(), currencyCd, currencyDescr, currencyRate);
            edit = false;
            resetBean();
        }
    }

    public List<Currency> getCurrencies() {

        return currencySessionBean1.retrieveCurrencies();
    }

    public void resetCurrencyList() {

        currencySessionBean1.removeCurrencies();
    }

    public boolean getEdit() {
        return this.edit;
    }

    public void edit(Currency currency) {
        this.currencyCd = currency.getCurrencycd();
        this.currencyDescr = currency.getCurrencydescription();
        this.currencyRate = currency.getCurrencyrate().doubleValue();
        beforeCurrency = currency;
        edit = true;
    }

}
